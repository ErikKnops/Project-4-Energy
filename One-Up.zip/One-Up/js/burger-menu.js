function clickBurgerMenu(aanuit) {
  if(aanuit == "aan") {
    document.getElementById("show-menu").style.width = "200px";
  } else {
    document.getElementById("show-menu").style.width = "0px";
  }
}
