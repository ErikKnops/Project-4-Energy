<?php
require("php/functies.php");
?>

<!DOCTYPE html>
<html lang="nl">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="One-Up">
  <meta name="author" content="Jesca Wiegers, Danny van Kampen, Erik Knöps, Sami Alouat">
  <meta name="keywords" content="">
  <link href="https://fonts.googleapis.com/css2?family=Tourney:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/master.css">
  <link rel="stylesheet" type="text/css" href="css/contact.css">
  <link rel="icon" type="image/x-icon" href="images/favicon.ico">
  <script type="text/javascript" src="js/burger-menu.js"></script>
  <title>One-Up</title>
</head>

<body>
  <?php get_header(); ?>

  <main class="container">
    <section class="titel">
      <h1 class="pagina-titel">Contact Formulier</h1>
      <h2 class="pagina-subtitel">Stuur ons een bericht!</h2>
    </section>

    <section class="content">
      <section class="content__text">

        <form>
          <input type="text" name="naam" placeholder="Naam" required>
          <input type="text" name="e-mail" placeholder="E-mail" required>
          <input type="text" name="cc" placeholder="Cc">
          <input type="text" name="typebericht" placeholder="Type Bericht" required>
          <input type="text" name="onderwerp" placeholder="Onderwerp" required>
          <input type="text" name="bericht" placeholder="Bericht" required>
          <input type="submit" name="submit" value="Verzenden">
        </form>

      </section>

      <img class="content__img" src="images/contact/message.png" alt="">

    </section>
  </main>

  <?php get_footer(); ?>

</body>
</html>
